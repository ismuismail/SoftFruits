package com.example.user.softfruits;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;


import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class List extends AppCompatActivity {

    ListView list;
    String ur = "http://projects.insprago.com/yachtbooking/Api/schedule_sales/2";
    JSONParser jParser = new JSONParser();
    public static ArrayList<String> booking_id, YachtName, reference_no, from_location, to_location, client_name, total_persons, from_time, to_time, total_hours, date, requirement, payment_type, actual_cost_collected, actual_cost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        list = (ListView) findViewById(R.id.listView);

        ActionBar v = getSupportActionBar();
        v.setTitle("BOOKING");

        try {

            if (android.os.Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {

            Toast.makeText(getApplicationContext(), "ERROR :" + e, Toast.LENGTH_SHORT).show();
        }


        java.util.List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("salesperson_id", "2"));
        JSONObject json = jParser.makeHttpRequest(ur, "GET", params);

        try {


            JSONArray ar = new JSONArray();
            ar = json.getJSONArray("schedule_sales");
            booking_id = new ArrayList<String>();
            YachtName = new ArrayList<String>();
            reference_no = new ArrayList<String>();
            from_location = new ArrayList<String>();
            to_location = new ArrayList<String>();
            client_name = new ArrayList<String>();
            total_persons = new ArrayList<String>();
            from_time = new ArrayList<String>();
            to_time = new ArrayList<String>();
            total_hours = new ArrayList<String>();
            date = new ArrayList<String>();
            requirement = new ArrayList<String>();
            payment_type = new ArrayList<String>();
            actual_cost = new ArrayList<String>();
            actual_cost_collected = new ArrayList<String>();


            for (int i = 0; i < ar.length(); i++) {
                JSONObject c = ar.getJSONObject(i);
                booking_id.add(c.getString("booking_id"));
                YachtName.add(c.getString("YachtName"));
                reference_no.add(c.getString("reference_no"));
                from_location.add(c.getString("from_location"));
                to_location.add(c.getString("to_location"));
                client_name.add(c.getString("client_name"));
                total_persons.add(c.getString("total_persons"));
                from_time.add(c.getString("from_time"));
                to_time.add(c.getString("to_time"));
                total_hours.add(c.getString("total_hours"));
                date.add(c.getString("date"));
                requirement.add(c.getString("requirement"));
                payment_type.add(c.getString("payment_type"));
                actual_cost.add(c.getString("actual_cost"));
                actual_cost_collected.add(c.getString("actual_cost_collected"));


            }


        } catch (JSONException e) {

            Toast.makeText(getApplicationContext(), "ERROR :" + e, Toast.LENGTH_SHORT).show();
        }




        Custom adapter = new Custom(List.this, reference_no, client_name, total_persons, total_hours, from_time, to_time);
        list.setAdapter(adapter);

    }
}
