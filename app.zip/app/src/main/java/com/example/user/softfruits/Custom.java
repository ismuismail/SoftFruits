package com.example.user.softfruits;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by USER on 9/20/2018.
 */

public class Custom extends BaseAdapter implements Adapter {
    Context context;

    ArrayList<String> reference_no, client_name, total_persons, total_hours, from_time, to_time;

    public Custom(Context applicationContext, ArrayList<String> reference_no, ArrayList<String> client_name, ArrayList<String> total_persons, ArrayList<String> total_hours, ArrayList<String> from_time, ArrayList<String> to_time) {
        this.context = applicationContext;
        this.reference_no = reference_no;
        this.client_name = client_name;
        this.total_persons = total_persons;
        this.total_hours = total_hours;
        this.from_time = from_time;
        this.to_time = to_time;

    }
    @Override
    public int getCount() {
        return reference_no.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView1;
        if (view == null) {
            gridView1 = new View(context);
            gridView1 = inflator.inflate(R.layout.custom, null);

        } else {

            gridView1 = (View) view;

        }

        final TextView referenceNumber = (TextView) gridView1.findViewById(R.id.textView);
        final TextView PersonDetails = (TextView) gridView1.findViewById(R.id.textView3);
        final TextView TimeDetails = (TextView) gridView1.findViewById(R.id.textView4);

        String ref_no,clientName,PersonCount,TotalHours,FromTime,ToTime;

        ref_no=reference_no.get(i);
        clientName=client_name.get(i);
        PersonCount=total_persons.get(i);
        TotalHours=total_hours.get(i);
        FromTime=from_time.get(i);
        ToTime=to_time.get(i);

        referenceNumber.setText("TRIP REF NO: "+ref_no);
        PersonDetails.setText(clientName+" and team - "+PersonCount+" MEMBERS");
        TimeDetails.setText("TIME SPENT - "+TotalHours+" HOURS - "+FromTime+" - "+ToTime+"");



        return gridView1;
    }
}
