package com.example.user.softfruits;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

public class login extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner sp;
    String[] items = {"SalesMan"};
    EditText username, password;
    String usernameString, passwordString, userflag, u_id, u_type;
    Button login;
    public static ArrayList<String> user_type, user_id, usernameArray, status, message;
    public static String ur = "http://projects.insprago.com/yachtbooking/Api/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sp = (Spinner) findViewById(R.id.spinner);
        sp.setOnItemSelectedListener(this);
        username = (EditText) findViewById(R.id.editText);
        password = (EditText) findViewById(R.id.editText2);
        login = (Button) findViewById(R.id.button);

        ActionBar v = getSupportActionBar();
        v.hide();

        try {
            if (android.os.Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        } catch (Exception e) {

        }


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, items);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                usernameString = username.getText().toString();
                passwordString = password.getText().toString();
                userflag = "2";


                if (!(usernameString.equals("")) && !(passwordString.equals(""))) {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("username", usernameString));
                    params.add(new BasicNameValuePair("password", passwordString));
                    params.add(new BasicNameValuePair("userflag", "2"));

                    Log.d("ins===", ur);
                    JSONParser jsonParser = new JSONParser();
                    JSONObject json = jsonParser.makeHttpRequest(ur, "POST", params);




                    String s;


                    try {
                        JSONArray ar = new JSONArray();
                        ar = json.getJSONArray("Response");

                        user_type = new ArrayList<String>();
                        user_id = new ArrayList<String>();
////                        usernameArray = new ArrayList<String>();
//
                        for (int i = 0; i < ar.length(); i++) {
                            JSONObject c = ar.getJSONObject(i);


                            user_id.add(c.getString("user_id"));
                            user_type.add(c.getString("user_type"));

                        }

                        u_id = user_id.get(0);
                        u_type = user_type.get(0);



                        s = json.getString("status");
                        if (s.equals("success")) {

                            String messag = json.getString("message");
                            Toast.makeText(login.this, ""+messag , Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), com.example.user.softfruits.List.class));

                        } else {

                            String ss = json.getString("message");
                            Toast.makeText(login.this, ""+ss, Toast.LENGTH_SHORT).show();

                        }


                    } catch (JSONException e) {

                        Toast.makeText(login.this, "Incorrect Email ID or Password..."+e, Toast.LENGTH_SHORT).show();

                    }
                } else {

                    Toast.makeText(login.this, "Please Enter In All Fields!!!", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
